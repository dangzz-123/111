# -*- coding: utf-8 -*-
import os
import sys

root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.append(root)
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from pydgc.pipelines.magi_batch_pipeline import MAGIBatchPipeline
from pydgc.pipelines import MAGIPipeline
from pydgc.utils import parse_arguments

# datasets = ["WIKI", "CORA", "ACM", "CITE", "DBLP", "BLOG", "FLICKR", "USPS_3", "HHAR_3", "PUBMED", "ROMAN", "ARXIV"]
datasets = ['ARXIV']
FULL = ["wiki", "cora", "acm", "cite", "dblp", "pubmed", "blog", "flickr", "roman", "usps", "hhar"]
BATCH = ["arxiv"]
for dataset in datasets:
    args = parse_arguments(dataset)
    if args.dataset_name.lower() in BATCH:
        pipeline = MAGIBatchPipeline(args)
    else:
        pipeline = MAGIPipeline(args)
    pipeline.run()
